<!DOCTYPE HTML>
<html>

<head>
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('style')); ?>/style.css" title="style" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1 style="font-size:240%;" ><a href="/home">ONLINE <span class="logo_colour">Clothin </span>System</a></h1>
          <h2> Branding Software</h2>
        </div>
      </div>
      <div id="menubar">
        <?php echo $__env->yieldContent('menubar'); ?>
      </div>
    </div>
    <div id="site_content">
      <?php echo $__env->yieldContent('site_content'); ?>
      
      
    </div>
    
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\includepreeg\Car Rent\laravel\resources\views/page/layout/main.blade.php ENDPATH**/ ?>