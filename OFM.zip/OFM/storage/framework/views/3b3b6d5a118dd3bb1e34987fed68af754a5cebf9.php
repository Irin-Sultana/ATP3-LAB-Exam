<?php $__env->startSection('title'); ?>
UMS-portal
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li class="selected"><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
          <li><a href="/portal/admin/verification">Verification</a></li>
          <li><a href="/portal/admin/userlist">Users</a></li>
          <li><a href="/portal/admin/course">Course</a></li>
          <li><a href="/portal/admin/viewtsf">TSFs</a></li>
          <li><a href="/portal/admin/department">Department</a></li>
          <li><a href="/portal/admin/section">Sections</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
      </div>
      <div id="content">
        <!-- insert the page content here -->
        <h1>portal view for admin</h1>
        <h1><?php echo e(session('type')); ?> : <?php echo e(session('username')); ?></h1>
        
                 <table style="width:100%; border-spacing:2;" border="4">
          

             <h1>Kazi Tanveer Islam</h1>
             <h1>System Admin</h1>
             <h1>i.kazitanveer@gmail.com</h1>
             <h1>01900000000</h1>


        </table>
      </div>


         


      <?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UmsLaravel\Full Project\laravel\resources\views/page/portal/admin/portal.blade.php ENDPATH**/ ?>