<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Login page</h1>
	
	<form method="post">
		<table>
			<tr>
				<td>Username</td>
				<td><input type="text" name="uname"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>
	</form>

	<div>
		<?php echo e(session('msg')); ?>

	</div>
</body>
</html><?php /**PATH C:\Xampp\htdocs\UMS\lavavel\lavavel\resources\views/login/index.blade.php ENDPATH**/ ?>