<?php $__env->startSection('title'); ?>
UMS-portal
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li class="selected"><a href="/portal">portal</a></li>
          <li>><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
        <li><a href="/portal/register/notice"> Notices</a></li>
         <li><a href="/portal/preRegistration"> pre registration</a></li>
          <li><a href="/portal/register/semester">semester</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
      </div>
      <div id="content">
        <!-- insert the page content here -->
        <h1>portal view for register</h1>
        <?php echo e(session('type')); ?> : <?php echo e(session('username')); ?>

        
        
      </div>


<form method="post">

  <table border="1">
    <tr><td colspan="4">Offered Cources</td></tr>
    <tr align="center">
      <td>id</td>
      <td>name</td>
      <td>department</td>
      <td>ACTION</td>
    </tr>

    <?php $__currentLoopData = $registerReg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr>
        <td><?php echo e($v->c_admin_id); ?></td>
        <td><?php echo e($v->c_admin_name); ?></td>
        <td><?php echo e($v->c_admin_dept); ?></td>
        <td>


       
        <a href="/portal/preRegistration/register/<?php echo e($v->c_admin_id); ?> ">Select</a>  
        
         
        </td>
      </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    </table>
   
  </form>

 <!-- room request starts -->

<div class="sidebar">
        
      </div>
      <div id="content">
       
      
      <div class="form_settings">

         <table style="width:100%; border-spacing:2;" border="4">
          <tr><td colspan="4">Room Request</td></tr>
          <tr><td>ID</td><td>Number</td><td>Message</td><td>Faculty</td><td>Date</td></tr>

          <?php $__currentLoopData = $roomrequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <td><?php echo e($d->r_id); ?></td>
             <td><?php echo e($d->r_number); ?></td>
             <td><?php echo e($d->r_message); ?></td>
              <td><?php echo e($d->r_faculty); ?></td>
                <td><?php echo e($d->r_date); ?></td>
            
            
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        
      </div>
      </div>







      <?php $__env->stopSection(); ?>




<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UmsLaravel\Full Project\laravel\resources\views/page/portal/register/portal.blade.php ENDPATH**/ ?>