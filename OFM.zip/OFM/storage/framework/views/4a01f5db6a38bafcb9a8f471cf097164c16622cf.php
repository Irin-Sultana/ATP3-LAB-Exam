<?php $__env->startSection('title'); ?>
UMS-Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li class="selected" ><a href="/home">Home</a></li>
                    <li><a href="/login">Login</a></li>
          <li><a href="/registration">Register</a></li>
        </ul>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Car Rent\laravel\resources\views/page/home/home.blade.php ENDPATH**/ ?>