<?php $__env->startSection('title'); ?>
UMS-Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li class="selected" ><a href="/home">Home</a></li>
        <li><a href="/login">Login</a></li>
          <li><a href="/registration">Register</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
      </div>
      <div id="content">
        <!-- insert the page content here -->
        <h1>portal view for register</h1>
        <?php echo e(session('type')); ?> : <?php echo e(session('username')); ?>

        
        

      <div class="form_settings">

         <table style="width:100%; border-spacing:2;" border="4">
          <tr><td>Title</td><td>description</td></tr>
          <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            
             <td><?php echo e($value->n_title); ?></td>
             <td colspan="6"><?php echo e($value->n_description); ?></td>
            
           
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        
      </div>
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\UmsLaravel\Full Project\laravel\resources\views/page/home/noticeDetails.blade.php ENDPATH**/ ?>