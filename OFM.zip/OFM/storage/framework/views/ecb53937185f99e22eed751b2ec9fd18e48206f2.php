<?php $__env->startSection('title'); ?>
UMS-Admin-Verification
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          
          <li class="selected"><a href="/portal/admin/productlist">productlist</a></li>
          <li><a href="/portal/admin/userlist">Users</a></li>
         
          <li><a href="/portal/admin/viewtsf">TSFs</a></li>
          <li><a href="/portal/admin/department">insertproduct</a></li>
          <li><a href="/portal/admin/section">Sections</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
 <font color="red">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  ⚠️<?php echo e($err); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
    <?php echo e(session('msg')); ?>

  </div>
      </font>





</div>
     <div class="form_settings">

         <table style="width:100%; border-spacing:2;" border="4">
          <tr><td>ID</td><td>Name</td><td>details</td><td>Action</td></tr>
          <?php $__currentLoopData = $productdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($value->p_id); ?></td>
             <td><?php echo e($value->p_name); ?></td>
             <td><h1><?php echo e($value->p_details); ?></h1></td>
          
             <td><a href="<?php echo e(route('admin.productlist.delete',$value->p_id )); ?>">Delete 

             
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        </div>
        




      <?php $__env->stopSection(); ?>


       <style type="text/css">
        textarea {
font: 100% arial; 
  width: 1200px;
  height: 60px;
}

      </style>






<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\includepreeg\Car Rent\laravel\resources\views/page/portal/admin/productlist.blade.php ENDPATH**/ ?>