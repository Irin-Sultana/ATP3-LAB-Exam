<?php $__env->startSection('title'); ?>
UMS-grade report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">ðŸš¹<?php echo e(session('username')); ?></a></li>
          <li><a href="/portal/preRegistration">pre registration</a></li>
          <li class="selected"><a href="/portal/student/grade_reports">Grade Report</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
     
  </div>
      
      <div id="content">
        <!-- insert the page content here -->
      <?php echo csrf_field(); ?>   
		 <form method="post">

  <table align="center" border="1">
    <tr><td colspan="6">Yours Grades</td></tr>
    <tr align="center">
      
	  
	  <td>COURSE ID</td>
      <td>MID</td>
      <td>FINAL</td>
      
	  
    </tr>
<?php $__currentLoopData = $grade_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr>
   
        <td><?php echo e($s->g_courseId); ?></td>
        <td><?php echo e($s->g_mid); ?></td>
        <td><?php echo e($s->g_final); ?></td>
        
       
		
      </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
   
    </table>
   
  </form>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/page/portal/student/grade_reports.blade.php ENDPATH**/ ?>