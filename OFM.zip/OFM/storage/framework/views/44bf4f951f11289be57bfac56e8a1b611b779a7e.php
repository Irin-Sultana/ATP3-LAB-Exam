<?php $__env->startSection('title'); ?>
UMS-portal-Pre Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
          <li><a href="/portal/faculty/tsf">update TSF</a></li>
          <li class="selected"><a href="/portal/preRegistration">pre registration</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
 <font color="red">
        

<div>
    <?php echo e(session('msg')); ?>

  </div>
      </font>


      </div>
      
        <!-- insert the page content here -->
        <h1>Pre Registration Faculty <mark><?php echo e(session('dept')); ?></mark> Department</h1>
       
<!-- table starts -->

<form method="post">

  <table border="1" align="right" cellspacing="10" >
    <tr><td colspan="4">Offered Cources</td></tr>
    <tr align="center">
      <td>COURSE NAME</td>
      <td>SEMESTER</td>
      <td>SECTION</td>
      <td>ACTION</td>
    </tr>

    <?php $__currentLoopData = $facReg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr bgcolor="#1bf7f7" >
        <td bgcolor="#64e885" ><?php echo e($s->c_register_name); ?></td>
        <td><?php echo e($s->c_register_semester); ?></td>
        <td><?php echo e($s->c_register_section); ?></td>
        <td>


         <a href="<?php echo e(route('preReg.updateFaculty',$s->c_register_id )); ?>">Select</a>
         
        </td>
      </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    </table>
   
  </form>

  




<!-- table ends -->


<!-- tsf table -->

        <table style="width:300;" align="left" border="1" cellspacing="10" >
          <tr style="outline: thin solid" align="center">
      
      <td  bgcolor="#1bf7f7" colspan="3" > <mark> FACULTY LIST  </mark></td>
      
      
    </tr>


          <tr>
            <td> NAME</td>
            <td> DEPARTMENT</td>
            <td bgcolor="#64e885" >TSF</td>

          </tr>



           <?php $__currentLoopData = $fList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr  >


        <td bgcolor="#faa693" ><?php echo e($s->t_name); ?></td>
        <td  bgcolor="#1bf7f7" ><?php echo e($s->t_dept); ?></td>
       
        
        <td bgcolor="#64e885" >


         <a id="mySelect2" href="<?php echo e(route('tsfview.index',$s->t_name )); ?>">➥</a>
         
        </td>
      </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>



        
        
     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/page/portal/preReg/faculty/preReg.blade.php ENDPATH**/ ?>