<?php $__env->startSection('title'); ?>
UMS-Admin-Department
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
          <li><a href="/portal/admin/productlist">productlist</a></li>
          <li><a href="/portal/admin/userlist">Users</a></li>
         
          <li class="selected"><a href="/portal/admin/insertproduct">product insert</a></li>
          <li><a href="/portal/admin/section">Sections</a></li>

          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
 <font color="red">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  ⚠️<?php echo e($err); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
    <?php echo e(session('msg')); ?>

  </div>
      </font>





</div>
      <div id="content">
        
        
      <div class="form_settings"> 
          <form   method="post">
            <p><h1><span>product Name</span><input placeholder="The product name should be unique" class="contact" type="text" name="p_name" value="" ></h1></p>
             <p><h1><span>product details</span><input placeholder="insert detaiils" class="contact" type="text" name="p_details" value="" ></h1></p>
            <p><input class="submit" type="submit" name="name" value="Submit" /></p>


        </div>


        
        
      </div>
      <?php $__env->stopSection(); ?>


       <style type="text/css">
        textarea {
font: 100% arial; 
  width: 1200px;
  height: 60px;
}

      </style>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\includepreeg\Car Rent\laravel\resources\views/page/portal/admin/insertproduct.blade.php ENDPATH**/ ?>