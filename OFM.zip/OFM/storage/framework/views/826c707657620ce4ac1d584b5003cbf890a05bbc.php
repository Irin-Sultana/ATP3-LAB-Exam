<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<?php echo e(session('type')); ?>

	<h1>Welcome Home! <?php echo e(session('username')); ?> </h1>
	<a href="<?php echo e(route('home.add')); ?>">Create</a> |
	<a href="<?php echo e(route('home.stdlist')); ?>">Student List</a> |
	<a href="/logout">Logout</a>	

</body>
</html><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/home/index.blade.php ENDPATH**/ ?>