<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
	<h1>Welcome Home! <?php echo e(session('username')); ?></h1>
	<a href="<?php echo e(route('home.add')); ?>">Create</a> |
	<a href="/stdList">Student List</a> |
	<a href="/logout">Logout</a>	

</body>
</html><?php /**PATH C:\Xampp\htdocs\UMS\lavavel\lavavel\resources\views/home/index.blade.php ENDPATH**/ ?>