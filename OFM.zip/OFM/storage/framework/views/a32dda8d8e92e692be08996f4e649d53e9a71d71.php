<!DOCTYPE html>
<html>
<head>
	<title>Student List</title>
</head>
<body>

	<h2>Student list </h2>
	<a href="/home">Back</a> |
	<a href="/logout">Logout</a>
	
	<br>
	<br>

	<table border="1">
		<tr align="center">
			<td>ID</td>
			<td>NAME</td>
			<td>CGPA</td>
			<td>Action</td>
		</tr>

		<?php $__currentLoopData = $stdlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			<tr>
				<td><?php echo e($s[0]); ?></td>
				<td><?php echo e($s[1]); ?></td>
				<td><?php echo e($s[2]); ?></td>
				<td>
					<a href="/details/<?php echo e($s[0]); ?>">Details</a> |
					<a href="/edit/<?php echo e($s[0]); ?>">Edit</a> |
					<a href="/delete/<?php echo e($s[0]); ?>">Delete</a> 
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</table>
		

</body>
</html><?php /**PATH C:\Xampp\htdocs\UMS\lavavel\lavavel\resources\views/home/show.blade.php ENDPATH**/ ?>