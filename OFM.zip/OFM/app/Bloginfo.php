<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
	protected $primaryKey = 'userId';
	public $timestamps = false;
	//protected $table = "user_table";
	//const CREATED_AT = "sfhdh";
	//const UPDATED_AT = "sdvfhsdfh";

}
